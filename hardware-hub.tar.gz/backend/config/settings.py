import os
from datetime import timedelta
from pathlib import Path

import dj_database_url
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY", "dev-only-change-in-production-not-for-staging-or-prod"
)

DEBUG = os.environ.get("DJANGO_DEBUG", "true").lower() in ("1", "true", "yes")


def _normalize_hostname(raw: str) -> str:
    """Strip scheme/path/port so pasted URLs work in DJANGO_ALLOWED_HOSTS."""
    h = raw.strip()
    if not h:
        return ""
    for prefix in ("https://", "http://"):
        if h.startswith(prefix):
            h = h[len(prefix) :]
            break
    return h.split("/")[0].split(":")[0].strip()


def _build_allowed_hosts() -> list[str]:
    raw = os.environ.get("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1")
    hosts: list[str] = []
    for part in raw.split(","):
        n = _normalize_hostname(part)
        if n and n not in hosts:
            hosts.append(n)
    # Optional single host if you prefer not to edit the comma list
    extra = _normalize_hostname(os.environ.get("PUBLIC_HOSTNAME", ""))
    if extra and extra not in hosts:
        hosts.append(extra)
    # Railway sets these at runtime (public URL is e.g. *.up.railway.app)
    for key in ("RAILWAY_PUBLIC_DOMAIN", "RAILWAY_PRIVATE_DOMAIN"):
        n = _normalize_hostname(os.environ.get(key, ""))
        if n and n not in hosts:
            hosts.append(n)
    # If RAILWAY_PUBLIC_DOMAIN is missing in the process (edge cases), Django's
    # leading-dot rule still allows any hostname ending in .railway.app
    if os.environ.get("RAILWAY_PROJECT_ID"):
        railway_wildcard = ".railway.app"
        if railway_wildcard not in hosts:
            hosts.append(railway_wildcard)
    return hosts


def _normalize_csrf_origin(raw: str) -> str:
    return raw.strip().rstrip("/")


def _build_csrf_trusted_origins(allowed_hosts: list[str]) -> list[str]:
    """
    Django 4+ checks Origin against CSRF_TRUSTED_ORIGINS for HTTPS.
    Merge explicit env, Railway public URL, and https://<host> for each concrete ALLOWED_HOSTS entry.
    """
    raw = os.environ.get("CSRF_TRUSTED_ORIGINS", "").strip()
    origins: list[str] = []
    for part in raw.split(","):
        o = _normalize_csrf_origin(part)
        if o and o not in origins:
            origins.append(o)
    for key in ("RAILWAY_PUBLIC_DOMAIN", "PUBLIC_HOSTNAME"):
        h = _normalize_hostname(os.environ.get(key, ""))
        if h:
            o = f"https://{h}"
            if o not in origins:
                origins.append(o)
    for h in allowed_hosts:
        if not h or h.startswith("."):
            continue
        if h in ("localhost", "127.0.0.1"):
            continue
        o = f"https://{h}"
        if o not in origins:
            origins.append(o)
    return origins


ALLOWED_HOSTS = _build_allowed_hosts()
CSRF_TRUSTED_ORIGINS = _build_csrf_trusted_origins(ALLOWED_HOSTS)

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "corsheaders",
    "apps.core",
    "apps.api",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

USE_SQLITE = os.environ.get("USE_SQLITE", "true").lower() in ("1", "true", "yes")

# On Railway/Render Docker: prefer DATABASE_URL (Postgres). SQLite in the container is ephemeral unless
# you attach a volume — use Postgres so admin and API data survive redeploys.

# Production on Vercel / serverless: set DATABASE_URL to PostgreSQL (Neon, Supabase, Railway, etc.).
# Do not raise here if missing — Vercel’s build imports settings before all env vars are applied;
# SQLite at runtime on Vercel is read-only (OperationalError) until DATABASE_URL is set.
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
if DATABASE_URL:
    DATABASES = {
        "default": dj_database_url.parse(
            DATABASE_URL,
            conn_max_age=0,
        )
    }
elif USE_SQLITE:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ.get("POSTGRES_DB", "hardware_hub"),
            "USER": os.environ.get("POSTGRES_USER", "postgres"),
            "PASSWORD": os.environ.get("POSTGRES_PASSWORD", ""),
            "HOST": os.environ.get("POSTGRES_HOST", "localhost"),
            "PORT": os.environ.get("POSTGRES_PORT", "5432"),
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-za"
TIME_ZONE = "Africa/Johannesburg"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
# Required for `manage.py collectstatic` (local deploys, Docker build, WhiteNoise in production).
STATIC_ROOT = BASE_DIR / "staticfiles"

# User uploads (repair intake documents). Use S3-compatible storage in production when ready.
MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"
FILE_UPLOAD_MAX_MEMORY_SIZE = 6 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 40 * 1024 * 1024

STORAGES = {
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
    },
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedStaticFilesStorage",
    },
}

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.AllowAny",
    ],
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_RENDERER_CLASSES": [
        "rest_framework.renderers.JSONRenderer",
    ],
}

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=60),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "ROTATE_REFRESH_TOKENS": False,
}

CORS_ALLOWED_ORIGINS = [
    o.strip()
    for o in os.environ.get(
        "CORS_ALLOWED_ORIGINS",
        "http://localhost:3000,http://127.0.0.1:3000",
    ).split(",")
    if o.strip()
]


def _first_nonempty_env(*keys: str) -> str:
    for key in keys:
        value = os.environ.get(key, "").strip()
        if value:
            return value
    return ""


def _first_env_int(*keys: str, default: int) -> int:
    for key in keys:
        raw = os.environ.get(key, "").strip()
        if raw:
            try:
                return int(raw)
            except ValueError:
                pass
    return default


def _first_env_bool(*keys: str, default: bool) -> bool:
    for key in keys:
        if key in os.environ and os.environ[key].strip() != "":
            return os.environ[key].lower() in ("1", "true", "yes")
    return default


# --- ERP-agnostic warranty HTTP (book repair step 2) ---
# Point at any HTTPS warranty endpoint (future ERP, middleware, or iPaaS). Not tied to a vendor name.
# Preferred env names: ERP_WARRANTY_* or WARRANTY_PROVIDER_*.
# Legacy: VISION_WARRANTY_* is still read if the newer keys are unset.
# POST JSON: device_catalog_id, brand, model_name, sku, imei — see apps/api/warranty_resolve.py.
# Response JSON: { "in_warranty": bool, "summary"?: str, "next_action"?: ... }
ERP_WARRANTY_API_URL = _first_nonempty_env(
    "ERP_WARRANTY_API_URL",
    "WARRANTY_PROVIDER_API_URL",
    "VISION_WARRANTY_API_URL",
)
ERP_WARRANTY_API_KEY = _first_nonempty_env(
    "ERP_WARRANTY_API_KEY",
    "WARRANTY_PROVIDER_API_KEY",
    "VISION_WARRANTY_API_KEY",
)
ERP_WARRANTY_API_TIMEOUT = _first_env_int(
    "ERP_WARRANTY_API_TIMEOUT",
    "WARRANTY_PROVIDER_API_TIMEOUT",
    "VISION_WARRANTY_API_TIMEOUT",
    default=15,
)
ERP_WARRANTY_VERIFY_SSL = _first_env_bool(
    "ERP_WARRANTY_VERIFY_SSL",
    "WARRANTY_PROVIDER_VERIFY_SSL",
    "VISION_WARRANTY_VERIFY_SSL",
    default=True,
)
ERP_WARRANTY_FALLBACK_STUB = _first_env_bool(
    "ERP_WARRANTY_FALLBACK_STUB",
    "WARRANTY_PROVIDER_FALLBACK_STUB",
    "VISION_WARRANTY_FALLBACK_STUB",
    default=True,
)

# Backward compatibility for code or docs that still reference VISION_* on settings.
VISION_WARRANTY_API_URL = ERP_WARRANTY_API_URL
VISION_WARRANTY_API_KEY = ERP_WARRANTY_API_KEY
VISION_WARRANTY_API_TIMEOUT = ERP_WARRANTY_API_TIMEOUT
VISION_WARRANTY_VERIFY_SSL = ERP_WARRANTY_VERIFY_SSL
VISION_WARRANTY_FALLBACK_STUB = ERP_WARRANTY_FALLBACK_STUB
